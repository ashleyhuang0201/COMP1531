'''
Team: You_Things_Can_Choose
Test file on server
Return value
'''

def echo(value):
    '''
    Returns the given value
    '''
    return value
